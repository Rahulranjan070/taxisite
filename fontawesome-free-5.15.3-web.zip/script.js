// $(document).on("ready", function(){
//     $(".booknow").on("click", function(){
//         $("#ds-none").removeAttr("#ds-none");
//     })
// })